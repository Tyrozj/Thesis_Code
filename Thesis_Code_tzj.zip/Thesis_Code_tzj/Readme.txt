GNSS_process文件夹下为模拟信号产生、捕获和跟踪模块的matlab代码。Gen_beidou_sig.m文件为信号产生模块，可以调节内部变量的参数改变信号，可以调用捕获模块和跟踪模块。
plot文件夹为画图模块。
costas文件夹下为锁相环的测试代码。
