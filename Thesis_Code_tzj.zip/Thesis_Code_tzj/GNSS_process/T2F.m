function [f,sf]=T2F(t,st)
%This is a function using the FFT to caculate a signal's Fourier
%tanslation
%input is the time and the signal vector .the length of time must greater
%than 2
%output is th frequency and the signal spectrum
dt=t(2)-t(1);
T=t(end);
df=1/T;
N=length(st);

f=-N/2*df:df:N/2*df-df;
sf1=fft(st);
sf=T/N*fftshift(sf1);
