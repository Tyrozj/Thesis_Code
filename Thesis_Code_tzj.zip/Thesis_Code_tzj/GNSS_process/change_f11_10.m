function seq_out = change_f11_10(seq_in)

ind1 = find(seq_in == -1);
ind2 = find(seq_in == 1);
seq_in(ind1) = ones(1,length(ind1));
seq_in(ind2) = zeros(1,length(ind2));
seq_out = seq_in;
end
