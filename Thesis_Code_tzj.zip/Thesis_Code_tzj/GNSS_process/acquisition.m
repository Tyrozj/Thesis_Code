function acqResults = acquisition(longSignal, settings)

%% Initialization =========================================================

Pulse_matrix_signal = Gen_Pulse(5,7);

% Find number of samples per spreading code ��Ƶ���������
samplesPerCode = round(settings.samplingFreq / ...
                        (settings.codeFreqBasis / settings.codeLength));
caCodesTable = makeCaTable(settings);
% Create two 1msec vectors of data to correlate with and one with zero DC
% signal1 = longSignal(1 : samplesPerCode).*caCodesTable(3,:);%�ź�
% signal2 = longSignal(samplesPerCode+1 : 2*samplesPerCode).*caCodesTable(1,:);
signal1 = longSignal(1 : samplesPerCode);%�ź�
signal2 = longSignal(samplesPerCode+1 : 2*samplesPerCode);
signal0DC = longSignal - mean(longSignal); 

% Find sampling period ��������
ts = 1 / settings.samplingFreq;

% Find phase points of the local carrier wave �����ز������
phasePoints = (0 : (samplesPerCode-1)) * 2 * pi * ts;

% Number of the frequency bins for the given acquisition band (500Hz steps)
% fbins
numberOfFrqBins = round(settings.acqSearchBand * 2) + 1;

% Generate all C/A codes and sample them according to the sampling
% freq.chsn
%



%--- Initialize arrays to speed up the code -------------------------------
% Search results of all frequency bins and code shifts (for one satellite)
results     = zeros(numberOfFrqBins, samplesPerCode);

% Carrier frequencies of the frequency bins
frqBins     = zeros(1, numberOfFrqBins);


%--- Initialize acqResults ------------------------------------------------
% Carrier frequencies of detected signals
acqResults.carrFreq     = zeros(1, 32);
% C/A code phases of detected signals
acqResults.codePhase    = zeros(1, 32);
% Correlation peak ratios of the detected signals
acqResults.peakMetric   = zeros(1, 32);

fprintf('(');
dd = zeros(numberOfFrqBins,length(signal1));

% Perform search for all listed PRN numbers ...
%% 
% PrnSequence = [3,6,15,18,21,22,26]; 
% posi = 1;
% for PRN = PrnSequence*Pulse_matrix_signal(posi,:)'
%     posi = posi + 1;
for PRN = 2 
%% Correlate signals ======================================================   
    %--- Perform DFT of C/A code ------------------------------------------
    caCodeFreqDom = conj(fft(caCodesTable(PRN, :)));

    %--- Make the correlation for whole frequency band (for all freq. bins)
    for frqBinIndex = 1:numberOfFrqBins

        %--- Generate carrier wave frequency grid (0.5kHz step) -----------
        frqBins(frqBinIndex) = settings.IF - ...
                               (settings.acqSearchBand/2) * 1000 + ...
                               0.5e3 * (frqBinIndex - 1);

        %--- Generate local sine and cosine �ز��������������������ź�-------------------------------
        sinCarr = sin(frqBins(frqBinIndex) * phasePoints);
        cosCarr = cos(frqBins(frqBinIndex) * phasePoints);

        %--- "Remove carrier" from the signal -----------------------------
        I1      = sinCarr .* signal1;
        Q1      = cosCarr .* signal1;
        I2      = sinCarr .* signal2;
        Q2      = cosCarr .* signal2;
        
        

        %--- Convert the baseband signal to frequency domain --------------
        IQfreqDom1 = fft(I1 + 1j*Q1);
        IQfreqDom2 = fft(I2 + 1j*Q2);
        
        %IQfreqDom1 = I1 + j*Q1;
        %IQfreqDom2 = I2 + j*Q2;
        
        

        %--- Multiplication in the frequency domain (correlation in time
        %domain)α�����
        convCodeIQ1 = IQfreqDom1 .* caCodeFreqDom;
        convCodeIQ2 = IQfreqDom2 .* caCodeFreqDom;
        

        %--- Perform inverse DFT and store correlation results ------------
        acqRes1 = abs(ifft(convCodeIQ1)) .^ 2;
        acqRes2 = abs(ifft(convCodeIQ2)) .^ 2;
        dd(frqBinIndex,:) = acqRes1;

        %mesh(dd);
        %acqRes1 = sqrt(abs(sum(real(convCodeIQ1))) .^ 2 + abs(imag(sum(convCodeIQ1))) .^ 2);
        %acqRes2 = sqrt(abs(sum(real(convCodeIQ2))) .^ 2 + abs(sum(imag(convCodeIQ2))) .^ 2);
        
        %--- Check which msec had the greater power and save that, will
        %"blend" 1st and 2nd msec but will correct data bit issues
        %if (max(acqRes1) > max(acqRes2))
        %    results(frqBinIndex, :) = acqRes1;
        %else
        %    results(frqBinIndex, :) = acqRes2;
        %end
        
        if (acqRes1 > acqRes2)
            results(frqBinIndex, :) = acqRes1;
        else
            results(frqBinIndex, :) = acqRes2;
        end
    end % frqBinIndex = 1:numberOfFrqBins

%% Look for correlation peaks in the results ==============================
    % Find the highest peak and compare it to the second highest peak
    % The second peak is chosen not closer than 1 chip to the highest peak
    
    %--- Find the correlation peak and the carrier frequency --------------
    [peakSize frequencyBinIndex] = max(max(results, [], 2));%ά��Ϊ2ά������ÿһ�е����ֵ���������
    figure(001); 
    
    subplot(2,1,1);
    
    plot(results(frequencyBinIndex,:));
    xlabel("������");
    ylabel("�����ֵ");
    title(['���Ϊ',num2str(PRN),'��α���ǲ�����']);
    %--- Find code phase of the same correlation peak ---------------------
    [peakSize codePhase] = max(max(results)); %���resultsΪ���󣬷���ÿһ�е����ֵ���һ��������
    subplot(2,1,2);
    stem(results(:,codePhase));
    xlabel("������Ƶƫ");
    ylabel("��ط�ֵ");
    
    figure;
    mesh(dd);

    %--- Find 1 chip wide C/A code phase exclude range around the peak ----
    samplesPerCodeChip   = round(settings.samplingFreq / settings.codeFreqBasis);
    excludeRangeIndex1 = codePhase - samplesPerCodeChip;
    excludeRangeIndex2 = codePhase + samplesPerCodeChip;

    %--- Correct C/A code phase exclude range if the range includes array
    %boundaries ����߽�
    if excludeRangeIndex1 < 2
        codePhaseRange = excludeRangeIndex2 : ...
                         (samplesPerCode + excludeRangeIndex1);
                         
    elseif excludeRangeIndex2 >= samplesPerCode
        codePhaseRange = (excludeRangeIndex2 - samplesPerCode) : ...
                         excludeRangeIndex1;
    else
        codePhaseRange = [1:excludeRangeIndex1, ...
                          excludeRangeIndex2 : samplesPerCode];
    end

    %--- Find the second highest correlation peak in the same freq. bin ---
    secondPeakSize = max(results(frequencyBinIndex, codePhaseRange));

    %--- Store result -----------------------------------------------------
    acqResults.peakMetric(PRN) = peakSize/secondPeakSize;
    
    % If the result is above threshold, then there is a signal ...
    if (peakSize/secondPeakSize) > settings.acqThreshold

%% Fine resolution frequency search ��ϸ�ֱ���Ƶ������=======================================
        
        %--- Indicate PRN number of the detected signal -------------------
        fprintf('%02d ', PRN);
        
        %--- Generate 10msec long C/A codes sequence for given PRN --------
        caCode = generateB3ICAcode10230(PRN);%����10ms�ĳ�C/A��
        
        codeValueIndex = floor((ts * (1:10*samplesPerCode)) / ...
                               (1/settings.codeFreqBasis)); %��ֵ����������Ƶ��38.192MHz����һ�����ʱ��ԼΪ26ns�����977ns�ڲ���37���㡣
                           
        longCaCode = caCode((rem(codeValueIndex, 10230) + 1));%rem��ʾȡa/b����������codeValueIndex����ͬ��37������ȡcaCode�е�1023��ֵ��
       %Ȼ��ӳ�䵽longCaCode�У���ɳ��Ⱥ�codeValueIndexһ���ĳ���
    
        %--- Remove C/A code modulation from the original signal ----------
        % (Using detected C/A code phase)
        xCarrier = ...
            signal0DC(codePhase:(codePhase + 4*samplesPerCode-codePhase)) ...%�������źźͳ�����ˡ�������λcodePhase����381920����longCaCode��
            .* longCaCode(codePhase:(codePhase + 4*samplesPerCode-codePhase));                                            %codePhaseλ�ñ�ʾ������λ��
        
        %--- Find the next highest power of two and increase by 8x --------
        fftNumPts = 64*(2^(nextpow2(length(xCarrier))));%nextpow2������ʾ�õ����ڵ��ڲ�����ģ��2����С�ݣ���length(xCarrier)����С��=19
        
        %--- Compute the magnitude of the FFT, find maximum and the
        %associated carrier frequency   ����FFT�Ĵ�С���ҵ����ֵ����֮��ص�Ƶ��
        fftxc = abs(fft(xCarrier, fftNumPts)); 
        
        uniqFftPts = ceil((fftNumPts + 1) / 2);
        [fftMax, fftMaxIndex] = max(fftxc(5 : uniqFftPts-5));
        
        fftFreqBins = (0 : uniqFftPts-1) * settings.samplingFreq/fftNumPts;
        
        %--- Save properties of the detected satellite signal -------------
        acqResults.carrFreq(PRN)  = fftFreqBins(fftMaxIndex);
        acqResults.carrFreq(PRN)
        acqResults.codePhase(PRN) = codePhase;
    
    else
        %--- No signal with this PRN --------------------------------------
        fprintf('. ');
    end   % if (peakSize/secondPeakSize) > settings.acqThreshold
    %figure();
    surf(dd);
end    % for PRN = satelliteList

%=== Acquisition is over ==================================================
fprintf(')\n');
