function CAcode = generateB3ICAcode10230(PRN)
% // generateCAcode.m generates one of the 31 GLONASS satellite CDMA codes.
% //
% // CAcode = generateCAcode(PRN)
% //
% //   Inputs:
% //       PRN         - PRN number of the sequence.
% //
% //   Outputs:
% //       CAcode      - a vector containing the desired C/A code sequence 
% //˵�����������Ǻŵ��øýű���                   (chips).  
g2s = [  113,  11,  13,  22,  30,  36,  44, 48, 88, 104, 116, ...
       129, 376, 418, 458, 682, 696, 707, 1078, 2069, 2248, ...
       2574, 2596, 2731, 4294, 4436, 4647, 4978, 4986, 1, 5209, ...
       5539, 6061, ... end of shifts for GPS satellites 
       ... Shifts for the ground GPS transmitter are not included
       ... Shifts for EGNOS and WAAS satellites (true_PRN = PRN + 87)
                 6488, 7130,  7165,  7403, 5879, 1681, 5080, 5938, ...
       3983, 6208, 7223, 2996, 1814, 6906, 6144, 4713, 7406, 7264, ...
       1766,5347,3515,7951,7054,3884,6067,4230,3803,869,3683,1205];


  %--- Generate G1 code -----------------------------------------------------
  %--- Initialize g1 output to speed up the function ---
  g1 = zeros(1, 10230);
  %--- Load shift register ---
  reg = -1*ones(1,13);
  reg_t = [-1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 1 1]; % -1Ϊ1��1Ϊ0����-1��1������ˣ��������
  g2shift = g2s(PRN); %reg2�ڶ�Ӧ���Ǻŵ���λ����
  %--- Generate all G1 signal chips based on the G1 feedback polynomial -----
  for i=1:8191
    g1(i)       = reg(13);
    saveBit     = reg(1)*reg(3)*reg(4)*reg(13);
    reg(2:13)   = reg(1:12);
    reg(1)      = saveBit;
 
  end
    g1 = [g1(1:8190),g1(1:10230-8190)]; %��G1�ض�1��Ƭ
  %--- Generate G2 code -----------------------------------------------------

  %--- Initialize g2 output to speed up the function ---
  g2 = zeros(1, 10230);
  %--- Load shift register ---
  %reg2 = [-1 1 -1 1 -1 -1 -1 -1 -1 -1 -1 -1 -1];
  
  reg2 = -1*ones(1,13);
  for i=1:g2shift
    reg2(i)       = reg2(13);    
    saveBit_reg2  = reg2(1)*reg2(5)*reg2(6)*reg2(7)*reg2(9)*reg2(10)*reg2(12)*reg2(13);
    reg2(2:13)  = reg2(1:12);
    reg2(1)     = saveBit_reg2;
  end
  %--- Generate all G2 signal chips based on the G2 feedback polynomial -----
  for i=1:8191
    g2(i)       = reg2(13);    
    saveBit     = reg2(1)*reg2(5)*reg2(6)*reg2(7)*reg2(9)*reg2(10)*reg2(12)*reg2(13);
    reg2(2:13)  = reg2(1:12);
    reg2(1)     = saveBit;
  end
  g2 = [g2(1:8191),g2(1:10230-8191)];
  %--- Form single sample C/A code by multiplying G1 and G2 -----------------
  CAcode = (g1 .* g2);
  ca_01 = change_f11_10(CAcode); %ͨ����-1��1ת��Ϊ1��0��Ľ�����Ա�CA��ͷ24bit��
                                 %����1�����ǵ�CA��ͷ24bit00051340Ϊ�˽��Ƶ�ͷ��ca_01���Ϊ000_000_000_101_001_011_100_000,
                                 %��txt�ĵ��ж�Ӧ��ȷ��
end
