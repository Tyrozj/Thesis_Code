d = [0.02 0.05 0.0625 0.1 0.125 0.2 0.25 0.35];
for i = 1:length(d)
    d(i)
    e_pse = 10*log10(d(i));
    e_sat = 10*log10(1-d(i));
end

